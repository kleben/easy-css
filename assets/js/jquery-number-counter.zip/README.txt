A Pen created at CodePen.io. You can find this one at http://codepen.io/syedrafeeq/pen/rcfsJ.

 jQuery counter to count up to a target number